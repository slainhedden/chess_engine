## data/dataset.py

from typing import List, Tuple
import torch
from torch import Tensor

class Dataset:
    def __init__(self, name: str, examples: List[str]) -> None:
        self.name = name
        self.examples = examples
        
    def __getitem__(self, index: int) -> Tuple[Tensor, Tensor]:
        example = self.examples[index]
        
        # Tokenize input and target sequences
        input_ids = self._tokenize(example['input'])
        target_ids = self._tokenize(example['target'])
        
        # Create attention mask
        attention_mask = self._create_attention_mask(input_ids)
        
        # Convert to tensors
        input_ids = torch.tensor(input_ids, dtype=torch.long)
        attention_mask = torch.tensor(attention_mask, dtype=torch.long) 
        target_ids = torch.tensor(target_ids, dtype=torch.long)
        
        return input_ids, attention_mask, target_ids
    
    def __len__(self) -> int:
        return len(self.examples)
    
    def _tokenize(self, text: str) -> List[int]:
        # Placeholder tokenization, replace with actual tokenizer
        return [ord(char) for char in text]
    
    def _create_attention_mask(self, input_ids: List[int]) -> List[int]:
        return [1] * len(input_ids)
