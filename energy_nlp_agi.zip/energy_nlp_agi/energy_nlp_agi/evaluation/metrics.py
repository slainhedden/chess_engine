## evaluation/metrics.py

import torch
import numpy as np
from typing import Tensor, Tuple, List 
from abc import ABC, abstractmethod

class Metric(ABC):
    """Base class for evaluation metrics."""
    
    @abstractmethod
    def compute(self, pred: Tensor, target: Tensor) -> float:
        """
        Computes the metric value.
        
        Args:
            pred (Tensor): The predicted outputs from the model.
            target (Tensor): The ground truth labels.
            
        Returns:
            float: The computed metric value.
        """
        pass
        
class Perplexity(Metric):
    """Perplexity metric for language models."""
    
    def compute(self, pred: Tensor, target: Tensor) -> float:
        """
        Computes perplexity.
        
        Args:
            pred (Tensor): The predicted log probabilities from the model.
            target (Tensor): The target word ids.
            
        Returns:
            float: The perplexity value.
        """
        cross_entropy = torch.nn.functional.cross_entropy(pred, target, reduction='mean')
        ppl = torch.exp(cross_entropy)
        return float(ppl.item())

class BLEU(Metric):    
    """BLEU metric for evaluating generated text."""
    
    def __init__(self, vocab, n_gram: int = 4, weights: Tuple[float] = (0.25, 0.25, 0.25, 0.25)):
        """
        Initializes BLEU metric.
        
        Args:
            vocab: The vocabulary to map token ids to words.
            n_gram (int): The maximum order of n-gram to use. Defaults to 4.
            weights (Tuple[float]): Weights for each n-gram order. Defaults to uniform weights.
        """
        self.vocab = vocab
        self.n_gram = n_gram
        self.weights = weights
        
    def compute(self, pred: Tensor, target: Tensor) -> float:
        """
        Computes BLEU score.
        
        Args:
            pred (Tensor): The predicted word ids from the model.
            target (Tensor): The target word ids.
            
        Returns:
            float: The BLEU score.
        """
        pred_text = [self._tensor_to_text(ids, self.vocab) for ids in pred]
        target_text = [self._tensor_to_text(ids, self.vocab) for ids in target]

        bleu_scores = [sentence_bleu([ref], hyp, self.weights) 
                       for ref, hyp in zip(target_text, pred_text)]
        
        return float(np.mean(bleu_scores))
        
    @staticmethod
    def _tensor_to_text(token_ids: Tensor, vocab) -> List[str]:
        """Converts token ids to words."""
        return [vocab.itos[id] for id in token_ids]
