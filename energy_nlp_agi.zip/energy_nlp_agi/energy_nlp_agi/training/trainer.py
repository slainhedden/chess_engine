## training/trainer.py
import torch
from torch.utils.data import DataLoader
from model.energy_nlp import EnergyNLPModel
from data.dataset import Dataset
from utils.energy_monitor import EnergyMonitor

class Trainer:
    def __init__(self, model: EnergyNLPModel, train_dataset: Dataset, energy_monitor: EnergyMonitor, 
                 batch_size: int = 32, learning_rate: float = 1e-4, device: str = 'cuda' if torch.cuda.is_available() else 'cpu'):
        self.model = model
        self.train_dataset = train_dataset
        self.energy_monitor = energy_monitor
        self.batch_size = batch_size
        self.learning_rate = learning_rate
        self.device = device
        
        self.model.to(self.device)
        self.train_dataloader = DataLoader(self.train_dataset, batch_size=self.batch_size, shuffle=True)
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=self.learning_rate)
        self.criterion = torch.nn.CrossEntropyLoss()

    def train(self, num_epochs: int = 10) -> None:
        self.model.train()
        
        for epoch in range(num_epochs):
            self.energy_monitor.start_monitor()
            epoch_loss = 0.0
            
            for batch_idx, (input_ids, attention_mask, labels) in enumerate(self.train_dataloader):
                input_ids = input_ids.to(self.device)
                attention_mask = attention_mask.to(self.device) 
                labels = labels.to(self.device)
                
                self.optimizer.zero_grad()
                
                outputs = self.model(input_ids, attention_mask=attention_mask)
                loss = self.criterion(outputs, labels)
                
                loss.backward()
                self.optimizer.step()
                
                epoch_loss += loss.item()
            
            avg_epoch_loss = epoch_loss / len(self.train_dataloader)
            energy_consumption = self.energy_monitor.get_energy_consumption()
            
            print(f"Epoch {epoch+1}/{num_epochs} | Avg Loss: {avg_epoch_loss:.4f} | Energy: {energy_consumption:.2f} Wh")
        
        print("Training completed.")
        return self.model
