## utils/energy_monitor.py
import time
from dataclasses import dataclass
from typing import Optional

try:
    import psutil
except ImportError:
    psutil = None

@dataclass
class EnergyMonitorConfig:
    """Configuration for the EnergyMonitor class."""
    sampling_rate: float = 1.0  # Sample energy consumption every 1 second by default

class EnergyMonitor:
    """Monitors energy consumption of the NLP model during training."""

    def __init__(self, config: Optional[EnergyMonitorConfig] = None):
        """Initialize the EnergyMonitor.

        Args:
            config: Configuration for the EnergyMonitor. If None, default config is used.
        """
        self.config = config or EnergyMonitorConfig()
        self._start_time: Optional[float] = None
        self._end_time: Optional[float] = None
        self._energy_samples: list[float] = []

    def start_monitor(self) -> None:
        """Start monitoring the energy consumption."""
        self._start_time = time.perf_counter()

    def _sample_energy(self) -> None:
        """Sample the current energy consumption."""
        if psutil is not None:
            cpu_power = psutil.cpu_freq().current * psutil.cpu_percent() / 100
            self._energy_samples.append(cpu_power)
        else:
            raise ImportError("psutil module is required for energy monitoring.")

    def stop_monitor(self) -> None:
        """Stop monitoring the energy consumption."""
        self._end_time = time.perf_counter()

    def get_energy_consumption(self) -> float:
        """Get the total energy consumption in Joules.

        Requires that start_monitor() and stop_monitor() have been called.

        Returns:
            Total energy consumption in Joules.

        Raises:
            ValueError: If start_monitor() or stop_monitor() have not been called.
            ImportError: If psutil module is not installed.
        """
        if self._start_time is None:
            raise ValueError("start_monitor() must be called before get_energy_consumption()")
        if self._end_time is None:
            raise ValueError("stop_monitor() must be called before get_energy_consumption()")

        elapsed_time = self._end_time - self._start_time
        num_samples = int(elapsed_time / self.config.sampling_rate)

        for _ in range(num_samples):
            self._sample_energy()

        total_energy = sum(self._energy_samples)
        self._energy_samples.clear()
        self._start_time = None
        self._end_time = None

        return total_energy
