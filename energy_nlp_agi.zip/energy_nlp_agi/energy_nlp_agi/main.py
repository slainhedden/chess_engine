## main.py

import torch
from model.energy_nlp import EnergyNLPModel, ModelArchitecture, PreTrainedWeights
from data.dataset import Dataset
from training.trainer import Trainer
from evaluation.metrics import perplexity, bleu_score
from utils.energy_monitor import EnergyMonitor

def main() -> None:
    # Set default hyperparameters
    default_architecture = ModelArchitecture(
        num_layers=6,
        hidden_size=768,
        intermediate_size=3072, 
        num_attention_heads=12,
        activation_function="gelu"
    )
    default_pretrained = PreTrainedWeights(
        encoder_weights=torch.load("pretrained/encoder.pt"),
        decoder_weights=torch.load("pretrained/decoder.pt")
    )

    # Initialize model
    model = EnergyNLPModel(
        architecture=default_architecture,
        pretrained_weights=default_pretrained
    )
    
    # Load datasets
    train_data = Dataset(name="wikitext", split="train")
    val_data = Dataset(name="wikitext", split="validation")
    
    # Initialize trainer
    energy_monitor = EnergyMonitor(
        gpu_ids=[0, 1],
        cpu_interval=0.1
    )

    trainer = Trainer(
        model=model,
        train_dataset=train_data,
        val_dataset=val_data,
        energy_monitor=energy_monitor,
        optimizer=torch.optim.AdamW(model.parameters(), lr=1e-4),
        num_epochs=10,
        grad_accum_steps=4,
        log_freq=50
    )

    # Train model
    print("Starting model training...")
    trained_model = trainer.train()

    # Evaluate model
    print("Evaluating trained model...")
    evaluator = Evaluator(
        model=trained_model,
        test_dataset=Dataset(name="wikitext", split="test"),
        metrics=[perplexity, bleu_score]
    )
    
    eval_scores = evaluator.evaluate()
    print(f"Evaluation scores: {eval_scores}")

    # Save fine-tuned model weights
    print("Saving fine-tuned model...")
    torch.save(trained_model.state_dict(), "finetuned_model.pt")
    
    print("All done!")

if __name__ == "__main__":
    main()

