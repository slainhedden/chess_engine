## model/layers.py
import torch
import torch.nn as nn
from torch import Tensor

class TransformerEncoder(nn.Module):
    def __init__(self, 
                 vocab_size: int,
                 embedding_dim: int,
                 num_heads: int,
                 num_layers: int,
                 dropout: float = 0.1):
        super().__init__()
        
        self.embedding = nn.Embedding(vocab_size, embedding_dim)
        encoder_layer = nn.TransformerEncoderLayer(d_model=embedding_dim, nhead=num_heads, dropout=dropout)
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
    
    def forward(self, input_ids: Tensor, attention_mask: Tensor) -> Tensor:
        """
        Args:
            input_ids (Tensor): Input token IDs of shape (batch_size, seq_len)
            attention_mask (Tensor): Attention mask of shape (batch_size, seq_len)
        Returns:
            Tensor: Encoded sequence of shape (seq_len, batch_size, embedding_dim)
        """
        embeddings = self.embedding(input_ids)
        embeddings = embeddings.permute(1, 0, 2)  # (seq_len, batch_size, embedding_dim)
        
        # Apply attention mask
        attention_mask = attention_mask.unsqueeze(1).unsqueeze(2)  # (batch_size, 1, 1, seq_len)
        attention_mask = (1.0 - attention_mask) * -10000.0
        
        encoded = self.encoder(embeddings, mask=attention_mask)
        return encoded
        

class TransformerDecoder(nn.Module):
    def __init__(self, 
                 vocab_size: int,
                 embedding_dim: int,
                 num_heads: int,
                 num_layers: int,
                 dropout: float = 0.1):
        super().__init__()
        
        self.embedding = nn.Embedding(vocab_size, embedding_dim)
        decoder_layer = nn.TransformerDecoderLayer(d_model=embedding_dim, nhead=num_heads, dropout=dropout)
        self.decoder = nn.TransformerDecoder(decoder_layer, num_layers=num_layers)
        
        self.fc = nn.Linear(embedding_dim, vocab_size)
    
    def forward(self, input_ids: Tensor, 
                     encoder_hidden_states: Tensor,
                     attention_mask: Tensor) -> Tensor:
        """        
        Args:
            input_ids (Tensor): Input token IDs of shape (batch_size, seq_len)
            encoder_hidden_states (Tensor): Encoder outputs of shape (seq_len, batch_size, embedding_dim)
            attention_mask (Tensor): Attention mask of shape (batch_size, seq_len)
        Returns:
            Tensor: Decoded logits of shape (batch_size, seq_len, vocab_size)
        """
        embeddings = self.embedding(input_ids)
        embeddings = embeddings.permute(1, 0, 2)  # (seq_len, batch_size, embedding_dim)
        
        # Apply attention mask 
        attention_mask = attention_mask.unsqueeze(1).unsqueeze(2)  # (batch_size, 1, 1, seq_len)
        attention_mask = (1.0 - attention_mask) * -10000.0
        
        decoded = self.decoder(tgt=embeddings,
                               memory=encoder_hidden_states,
                               tgt_mask=attention_mask,
                               memory_mask=attention_mask)
        
        decoded = decoded.permute(1, 0, 2)  # (batch_size, seq_len, embedding_dim)
        logits = self.fc(decoded)
        return logits
