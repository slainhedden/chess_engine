## model/energy_nlp.py
from typing import Tuple

import torch
import torch.nn as nn
from torch import Tensor
from transformers import AutoTokenizer

from .layers import TransformerEncoder, TransformerDecoder


class ModelArchitecture:
    def __init__(self, num_layers: int = 6, hidden_size: int = 768):
        self.encoder = TransformerEncoder(num_layers, hidden_size)
        self.decoder = TransformerDecoder(num_layers, hidden_size)
        self.num_layers = num_layers
        self.hidden_size = hidden_size


class PreTrainedWeights:
    def __init__(self, encoder_weights: Tensor, decoder_weights: Tensor):
        self.encoder_weights = encoder_weights
        self.decoder_weights = decoder_weights


class EnergyNLPModel(nn.Module):
    def __init__(self, 
                 architecture: ModelArchitecture = ModelArchitecture(),
                 pretrained_weights: PreTrainedWeights = None,
                 tokenizer_name: str = "bert-base-uncased"):
        super().__init__()
        self.architecture = architecture
        self.encoder = architecture.encoder
        self.decoder = architecture.decoder
        self.tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)

        if pretrained_weights:
            self.load_state_dict(dict(
                encoder=pretrained_weights.encoder_weights,
                decoder=pretrained_weights.decoder_weights
            ), strict=False)

    def forward(self, input_ids: Tensor, attention_mask: Tensor) -> Tensor:
        encoded = self.encoder(input_ids, attention_mask)
        decoded = self.decoder(encoded, attention_mask)
        return decoded

    def generate(self, input_str: str, max_length: int = 128) -> str:
        input_ids = self.encode(input_str)
        attention_mask = self.get_attention_mask(input_ids)
        
        output = self.forward(input_ids, attention_mask)
        output_str = self.decode(output, max_length)

        return output_str

    def encode(self, text: str) -> Tensor:
        # Tokenize the input text
        tokens = self.tokenizer.tokenize(text)
        # Convert tokens to input IDs
        input_ids = self.tokenizer.convert_tokens_to_ids(tokens)
        # Return a tensor of shape (batch_size, seq_len)
        return torch.tensor([input_ids])

    def decode(self, tensor: Tensor, max_length: int) -> str:
        # Convert output tensor to token IDs
        output_ids = tensor.argmax(dim=-1).squeeze().tolist()
        # Truncate to max_length if necessary
        output_ids = output_ids[:max_length]
        # Convert token IDs to string
        output_str = self.tokenizer.decode(output_ids)
        return output_str

    def get_attention_mask(self, input_ids: Tensor) -> Tensor:
        # Create attention mask from input IDs
        attention_mask = (input_ids != self.tokenizer.pad_token_id).float()
        return attention_mask
